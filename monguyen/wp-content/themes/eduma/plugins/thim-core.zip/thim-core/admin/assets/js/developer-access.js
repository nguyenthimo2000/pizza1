(function ($) {
    $(document).ready(function () {
        var clipboard = new Clipboard('.tc-btn-copy-link');
        var $button = $('.tc-btn-copy-link');
        var $text = $('#tc-link-developer-access');
    });
})(jQuery);